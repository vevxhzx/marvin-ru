import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { X, Trash2, Check } from 'lucide-react'
import { parseNum } from '../lib/api'

// Глобальный слушатель движения курсора для градиентной подсветки карточек .c (--mx, --my)
if (typeof document !== 'undefined') {
  document.addEventListener('pointermove', (e) => {
    const c = e.target?.closest?.('.c')
    if (!c) return
    const r = c.getBoundingClientRect()
    c.style.setProperty('--mx', `${e.clientX - r.left}px`)
    c.style.setProperty('--my', `${e.clientY - r.top}px`)
  })
}

export function Card({ className = '', variant = '', col = '', i = 0, children, lift, ...p }) {
  const vClass = variant === 'hero' ? 'hero' : variant === 'p1' ? 'p1' : variant === 'p2' ? 'p2' : variant === 'blk' ? 'blk' : variant === 'chart' ? 'chart' : ''
  const colClass = col ? (col.startsWith('s') ? col : `s${col}`) : ''
  return (
    <section className={`c ${vClass} ${colClass} r ${lift ? 'lift' : ''} ${className}`} style={{ '--i': i }} {...p}>
      {children}
    </section>
  )
}

/* Число, которое считает от 0 до значения: 1.8s expo-out, задержка 500ms ровно как в эталоне */
export function useCountUp(target, { duration = 1800, delay = 500 } = {}) {
  const [v, setV] = useState(target)
  const prev = useRef(0)
  useEffect(() => {
    const to = Number.isFinite(target) ? target : 0
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || document.documentElement.classList.contains('no-anim')) {
      setV(to); prev.current = to; return
    }
    let raf
    const t0 = performance.now() + delay
    const tick = (now) => {
      const p = Math.min(Math.max((now - t0) / duration, 0), 1)
      const current = p < 1 ? to * (1 - Math.pow(2, -10 * p)) : to
      setV(current)
      if (p < 1) raf = requestAnimationFrame(tick)
      else prev.current = to
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, duration, delay])
  return v
}

/* Обёртка: <Num value={84007} fmt={money} /> — анимированное число */
export function Num({ value, fmt = (n) => Math.round(n).toLocaleString('ru-RU').replace(/\s/g, '\u00a0'), className = '' }) {
  const v = useCountUp(typeof value === 'number' ? value : 0)
  return <span className={`n ${className}`}>{fmt(v)}</span>
}

/* Заголовок раздела: компактный, спокойный. idx — счётчик справа от названия */
export function Section({ title, idx, hint, action, children, className = '', i = 0 }) {
  return (
    <section className={`r ${className}`} style={{ '--i': i }}>
      {(title || action) && (
        <div className="mb-3 flex flex-wrap items-end justify-between gap-x-6 gap-y-2">
          <div className="min-w-0">
            <div className="flex items-baseline gap-2">
              {title && <h2 className="text-[20px] font-semibold tracking-[-0.03em]">{title}</h2>}
              {idx != null && idx !== 0 && <span className="mono text-[12px] text-accent">{idx}</span>}
            </div>
            {hint && <div className="muted mt-1 max-w-[520px] text-[13px] leading-snug">{hint}</div>}
          </div>
          {action && <div className="flex items-center gap-2">{action}</div>}
        </div>
      )}
      {children}
    </section>
  )
}

/* Шапка страницы: заголовок + подпись + действия справа */
export function PageHead({ kicker, title, idx, right, children, sub }) {
  return (
    <header className="top r mb-6 sm:mb-8" style={{ '--i': 0 }}>
      <div className="min-w-0">
        {kicker && <div className="mono text-[11px] uppercase tracking-wider text-[var(--ink3)] mb-1">{kicker}</div>}
        <h1 className="text-[34px] sm:text-[44px] font-semibold tracking-[-0.045em] leading-[1.04]">
          {title}{idx != null && idx !== 0 && <span className="mono text-[18px] ml-3 align-middle text-accent">{idx}</span>}
        </h1>
        {sub && <p className="sub">{sub}</p>}
      </div>
      {right && <div className="hr">{right}</div>}
      {children}
    </header>
  )
}

/* Пустые состояния: тонкий глиф в стиле сайта + подсказка-кнопка, которая открывает чат с готовой фразой */
const GLYPHS = {
  calendar: <><rect x="6" y="10" width="36" height="32" rx="6" /><path d="M6 20h36M16 6v8M32 6v8" /><circle cx="24" cy="31" r="3" fill="currentColor" stroke="none" /></>,
  tasks: <><path d="M10 14l4 4 8-8" /><path d="M10 26l4 4 8-8" /><path d="M10 38l4 4 8-8" /><path d="M28 14h12M28 26h12M28 38h12" /></>,
  money: <><circle cx="24" cy="24" r="17" /><path d="M24 13v22M19 18h7a4 4 0 010 8h-7M19 30h9" /></>,
  debt: <><path d="M8 36V14a4 4 0 014-4h24a4 4 0 014 4v22" /><path d="M8 20h32" /><path d="M14 30h8" /></>,
  mind: <><path d="M17 40c-6 0-10-4-10-10 0-4 2-7 5-8-1-6 3-11 9-11 2 0 4 1 5 2 1-1 3-2 5-2 6 0 10 5 9 11 3 1 5 4 5 8 0 6-4 10-10 10H17z" /><path d="M24 22v18M19 30l5-4 5 4" /></>,
  memory: <><circle cx="24" cy="24" r="17" /><path d="M24 13v11l7 5" /></>,
  sleep: <><path d="M30 8a16 16 0 1010 24A14 14 0 0130 8z" /></>,
  search: <><circle cx="21" cy="21" r="12" /><path d="M30 30l10 10" /></>,
}
export function Empty({ icon, glyph, text, sub, hint, onHint, compact }) {
  return (
    <div className={`empty flex flex-col items-start justify-center ${compact ? 'py-5' : 'py-8 sm:py-10'}`}>
      {glyph && GLYPHS[glyph] ? (
        <svg width={compact ? 36 : 44} height={compact ? 36 : 44} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="empty-glyph mb-3">{GLYPHS[glyph]}</svg>
      ) : icon ? <div className="mb-3 text-2xl">{icon}</div> : null}
      <div className="h4">{text}</div>
      {sub && <div className="muted mt-1 text-[13.5px]">{sub}</div>}
      {hint && <button type="button" className="btn-soft btn-sm mt-4" onClick={() => onHint ? onHint(hint) : window.dispatchEvent(new CustomEvent('assistant:chat', { detail: { text: hint } }))}>«{hint}» <span>↗</span></button>}
    </div>
  )
}

/* Свайп строки на телефоне: вправо — onRight (выполнить), влево — onLeft (удалить).
   Показывает подложку с иконкой; срабатывает при сдвиге > 88px или быстром флике. */
/* Свайп как в iOS: короткий свайп раскрывает кнопку (удалить / готово), длинный — выполняет сразу.
   Открытая строка одна на всю страницу; тап по строке или в стороне — закрывает. Только touch. */
let _closeOpenSwipe = null
export function Swipe({ children, onLeft, onRight, leftLabel = 'удалить', rightLabel = 'готово', leftIcon, rightIcon, className = '', disabled }) {
  const [dx, setDx] = useState(0)
  const [openSide, setOpenSide] = useState(null)   // 'left' | 'right' | null — кнопка раскрыта
  const [flying, setFlying] = useState(false)
  const st = useRef(null)
  const box = useRef(null)
  const fire = useRef(false)
  const dxRef = useRef(0)
  const BTN = 84
  const fullTh = () => Math.max(150, (box.current?.offsetWidth || 360) * 0.5)
  const setX = (v) => { dxRef.current = v; setDx(v) }

  const close = () => { setOpenSide(null); setX(0); if (_closeOpenSwipe === close) _closeOpenSwipe = null }
  useEffect(() => {
    if (!openSide) return
    const h = (e) => { if (!box.current?.contains(e.target)) close() }
    document.addEventListener('touchstart', h, { passive: true })
    document.addEventListener('scroll', close, { passive: true, capture: true })
    return () => { document.removeEventListener('touchstart', h); document.removeEventListener('scroll', close, { capture: true }) }
  }, [openSide]) // eslint-disable-line
  useEffect(() => () => { if (_closeOpenSwipe === close) _closeOpenSwipe = null }, []) // eslint-disable-line

  const go = (side) => {
    setFlying(true); navigator.vibrate?.(10)
    const w = box.current?.offsetWidth || 400
    setX(side === 'right' ? w + 40 : -(w + 40))
    setTimeout(() => { setOpenSide(null); (side === 'right' ? onRight : onLeft)?.(); setTimeout(() => { setFlying(false); setX(0) }, 60) }, 180)
  }
  const open = (side) => {
    if (_closeOpenSwipe && _closeOpenSwipe !== close) _closeOpenSwipe()
    _closeOpenSwipe = close
    setOpenSide(side); setX(side === 'right' ? BTN : -BTN); navigator.vibrate?.(6)
  }

  const onStart = (e) => {
    if (disabled || flying) return
    const t = e.touches[0]
    st.current = { x: t.clientX, y: t.clientY, t: Date.now(), lock: null, base: dxRef.current }
  }
  const onMove = (e) => {
    if (!st.current) return
    const t = e.touches[0]; const ddx = t.clientX - st.current.x, ddy = t.clientY - st.current.y
    if (st.current.lock == null) { if (Math.abs(ddx) < 6 && Math.abs(ddy) < 6) return; st.current.lock = Math.abs(ddx) > Math.abs(ddy) ? 'x' : 'y' }
    if (st.current.lock !== 'x') return
    let v = st.current.base + ddx
    const allowed = (v > 0 && onRight) || (v < 0 && onLeft)
    if (!allowed) v = v * 0.15
    const th = fullTh()
    // за порогом «полного» свайпа строка идёт с сопротивлением
    if (Math.abs(v) > th) v = Math.sign(v) * (th + (Math.abs(v) - th) * 0.35)
    const armed = Math.abs(v) >= th
    if (armed && !fire.current) { fire.current = true; navigator.vibrate?.(8) }
    if (!armed) fire.current = false
    setX(v)
  }
  const onEnd = () => {
    if (!st.current) return
    const cur = dxRef.current
    const moved = st.current.lock === 'x'
    const dt = Date.now() - st.current.t
    const delta = cur - st.current.base
    const fast = dt < 250 && Math.abs(delta) > 30
    const side = cur > 0 ? 'right' : 'left'
    const can = side === 'right' ? !!onRight : !!onLeft
    st.current = null; fire.current = false
    if (!moved) return
    if (!can) { close(); return }
    if (Math.abs(cur) >= fullTh() || (fast && Math.abs(delta) > 110)) go(side)
    else if (Math.abs(cur) >= BTN * 0.55 || (fast && delta * (side === 'right' ? 1 : -1) > 0)) open(side)
    else close()
  }
  // пока строка раскрыта — тап по ней только закрывает, не открывает форму
  const onClickCapture = (e) => { if (openSide) { e.stopPropagation(); e.preventDefault(); close() } }

  const th = fullTh()
  const armed = Math.abs(dx) >= th && !openSide
  const reveal = Math.abs(dx)
  const LI = leftIcon || <Trash2 size={18} strokeWidth={2.2} />
  const RI = rightIcon || <Check size={18} strokeWidth={2.6} />
  const dragging = !!st.current
  const trans = dragging ? 'none' : flying ? 'transform .2s var(--ease-io)' : 'transform .34s var(--ease-spring)'
  return (
    <div ref={box} className={`swipe ${openSide ? 'open' : ''} ${dx !== 0 || flying ? 'active' : ''} ${className}`} onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd} onTouchCancel={onEnd}>
      {onRight && (
        <div className={`swipe-bg right ${dx > 0 ? 'show' : ''} ${armed && dx > 0 ? 'armed' : ''}`}>
          <button type="button" tabIndex={-1} className="swipe-act" onClick={(e) => { e.stopPropagation(); go('right') }} style={{ width: Math.max(BTN, reveal) }}>
            {RI}<span>{rightLabel}</span>
          </button>
        </div>
      )}
      {onLeft && (
        <div className={`swipe-bg left ${dx < 0 ? 'show' : ''} ${armed && dx < 0 ? 'armed' : ''}`}>
          <button type="button" tabIndex={-1} className="swipe-act" onClick={(e) => { e.stopPropagation(); go('left') }} style={{ width: Math.max(BTN, reveal) }}>
            {LI}<span>{leftLabel}</span>
          </button>
        </div>
      )}
      <div className="swipe-fg" onClickCapture={onClickCapture} style={{ transform: `translateX(${dx}px)`, transition: trans }}>{children}</div>
    </div>
  )
}

/* Шторка остаётся в DOM ещё ~240 мс после закрытия, чтобы успеть уехать вниз */
export function useSheetPresence(open, ms = 240) {
  const [shown, setShown] = useState(open)
  const [closing, setClosing] = useState(false)
  useEffect(() => {
    if (open) { setShown(true); setClosing(false); return }
    if (!shown) return
    setClosing(true)
    const t = setTimeout(() => { setShown(false); setClosing(false) }, ms)
    return () => clearTimeout(t)
  }, [open]) // eslint-disable-line
  return [shown, closing]
}

/* стек открытых шторок: пока есть хоть одна — нижние вкладки спрятаны; верхняя знает, что она верхняя */
let _sheetSeq = 0
const _stack = []
const _stackEv = new EventTarget()
export function Sheet({ open, onClose, title, sub, children, wide }) {
  const [shown, closing] = useSheetPresence(open)
  const idRef = useRef(0)
  const [, force] = useState(0)
  useEffect(() => {
    if (!open) return
    const h = (e) => { if (e.key === 'Escape' && _stack[_stack.length - 1] === idRef.current) onClose() }
    window.addEventListener('keydown', h)
    document.body.style.overflow = 'hidden'
    idRef.current = ++_sheetSeq; _stack.push(idRef.current)
    document.body.classList.add('sheet-open'); _stackEv.dispatchEvent(new Event('change'))
    return () => {
      window.removeEventListener('keydown', h)
      const i = _stack.indexOf(idRef.current); if (i >= 0) _stack.splice(i, 1)
      if (!_stack.length) { document.body.style.overflow = ''; document.body.classList.remove('sheet-open') }
      _stackEv.dispatchEvent(new Event('change'))
    }
  }, [open, onClose])
  useEffect(() => { const h = () => force((x) => x + 1); _stackEv.addEventListener('change', h); return () => _stackEv.removeEventListener('change', h) }, [])
  if (!shown) return null
  const behind = open && _stack.length > 1 && _stack[_stack.length - 1] !== idRef.current
  // рисуем в <body>, а не внутри страницы: иначе анимация страницы (transform/filter)
  // превращает position:fixed в «относительно страницы» и окно уезжает
  return createPortal(
    <div className={`sheet-backdrop ${closing ? 'closing' : ''} ${behind ? 'behind' : ''}`} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`sheet ${wide ? 'sm:!max-w-2xl' : ''}`}>
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <h3 className="h2">{title}</h3>
            {sub && <div className="muted mt-1 text-[13px]">{sub}</div>}
          </div>
          <button className="btn-icon shrink-0" onClick={onClose}><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  )
}

export function Field({ label, hint, error, children, className = '' }) {
  return (
    <label className={`block ${className}`}>
      <div className="mb-1.5 flex items-baseline justify-between"><span className="label">{label}</span>{hint && <span className="faint text-[11px]">{hint}</span>}</div>
      {children}
      {error && <div className="neg mt-1 text-[12px]">{error}</div>}
    </label>
  )
}

/* Денежное поле: пробелы-разделители, запятая→точка, min/max с подсказкой */
export function Money({ value, onChange, min, max, placeholder = '0', className = '', big, autoFocus, required, suffix = '₽' }) {
  const n = parseNum(value)
  const tooBig = max != null && !Number.isNaN(n) && n > max
  const tooSmall = min != null && !Number.isNaN(n) && n < min
  const bad = tooBig || tooSmall || (value !== '' && Number.isNaN(n))
  return (
    <div className="relative">
      <input inputMode="decimal" autoFocus={autoFocus} required={required}
        className={`input num pr-9 ${big ? '!text-[30px] !font-medium !tracking-tight' : ''} ${bad ? 'err' : ''} ${className}`}
        placeholder={placeholder} value={value}
        onChange={(e) => onChange(e.target.value.replace(/[^\d\s.,\u00a0-]/g, ''))}
        onBlur={() => { if (!Number.isNaN(n)) onChange(n.toLocaleString('ru-RU')) }} />
      <span className={`faint pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 ${big ? 'text-[20px]' : 'text-[14px]'}`}>{suffix}</span>
    </div>
  )
}

/* Число, редактируемое прямо на месте (Enter — сохранить, Esc — отмена) */
export function Inline({ value, onSave, fmt = (v) => v, min, max, className = '', type = 'num', title = 'Нажмите, чтобы изменить' }) {
  const [edit, setEdit] = useState(false)
  const [v, setV] = useState('')
  const [err, setErr] = useState('')
  const ref = useRef(null)
  useEffect(() => { if (edit) { ref.current?.focus(); ref.current?.select() } }, [edit])
  const start = () => { setV(type === 'num' ? String(value ?? '') : (value ?? '')); setErr(''); setEdit(true) }
  const commit = async () => {
    if (!edit) return
    let out = v
    if (type === 'num') {
      const n = parseNum(v)
      if (Number.isNaN(n)) { setErr('число'); return }
      if (min != null && n < min) { setErr(`≥ ${fmt(min)}`); return }
      if (max != null && n > max) { setErr(`≤ ${fmt(max)}`); return }
      out = n
    } else if (!String(v).trim()) { setErr('пусто'); return }
    if (out === value) { setEdit(false); return }
    try { await onSave(out); setEdit(false) } catch (e) { setErr(e.message || 'ошибка') }
  }
  if (!edit) return <button type="button" title={title} onClick={start} className={`editable text-left ${className}`}>{fmt(value)}</button>
  return (
    <span className="relative inline-flex flex-col">
      <input ref={ref} value={v} onChange={(e) => setV(e.target.value)} inputMode={type === 'num' ? 'decimal' : 'text'}
        onBlur={commit} onKeyDown={(e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEdit(false) }}
        className={`inline-edit ${className}`} style={{ width: `${Math.max(4, String(v).length + 1)}ch` }} />
      {err && <span className="neg absolute -bottom-4 left-0 whitespace-nowrap text-[11px]">{err}</span>}
    </span>
  )
}

export function Seg({ value, onChange, options, className = '' }) {
  return (
    <div className={`sg ${className}`}>
      {options.map(([v, l]) => (
        <span
          key={v}
          role="button"
          tabIndex={0}
          className={v === value ? 'on' : ''}
          onClick={() => onChange(v)}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onChange(v) } }}
        >
          {l}
        </span>
      ))}
    </div>
  )
}

export function Pill({ children, warn, className = '', ...p }) {
  return <span className={`pl ${warn ? 'y' : ''} ${className}`} {...p}>{children}</span>
}

export function Rowi({ time, title, sub, right, className = '', onClick }) {
  return (
    <div className={`rowi ${onClick ? 'cursor-pointer' : ''} ${className}`} onClick={onClick}>
      {time && <time>{time}</time>}
      <div className="t">
        {title}
        {sub && <small>{sub}</small>}
      </div>
      {right}
    </div>
  )
}

export function Bars({ values = [], labels = [], height = 62, className = '' }) {
  const max = Math.max(...values, 1)
  return (
    <div className={className}>
      <div className="bars" style={{ height }}>
        {values.map((v, i) => (
          <i
            key={i}
            style={{
              '--h': `${Math.round((v / max) * 100)}%`,
              '--k': i,
            }}
          />
        ))}
      </div>
      {labels.length > 0 && (
        <div className="bl mono">
          {labels.map((l, i) => <span key={i}>{l}</span>)}
        </div>
      )}
    </div>
  )
}

export function FlowBar({ items = [], note, legend, className = '' }) {
  return (
    <div className={className}>
      <div className="flow">
        {items.map((it, i) => (
          <i key={i} style={{ width: `${it.pct}%`, background: it.color }} title={`${it.label}: ${it.pct}%`} />
        ))}
      </div>
      {(legend || note) && (
        <div className="fl">
          <span>{legend}</span>
          {note && <span>{note}</span>}
        </div>
      )}
    </div>
  )
}

export function Toggle({ on, onChange, label }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={!!on}
      aria-label={label}
      className={`tgl ${on ? '' : 'off'}`}
      onClick={() => onChange(!on)}
    />
  )
}

export function Swatch({ color, active, onClick, title }) {
  return (
    <i
      style={{ '--c': color }}
      className={active ? 'on' : ''}
      onClick={() => onClick(color)}
      title={title || color}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter') onClick(color) }}
    />
  )
}

export function Pills({ value, onChange, options, className = '' }) {
  return (
    <div className={`flex flex-wrap gap-1.5 ${className}`}>
      {options.map(([v, l]) => <button type="button" key={v} className={`pill ${v === value ? 'on' : ''}`} onClick={() => onChange(v)}>{l}</button>)}
    </div>
  )
}

export function Stat({ label, value, sub, tone, big }) {
  const color = tone === 'green' ? 'pos' : tone === 'red' ? 'neg' : tone === 'orange' ? 'warn' : tone === 'accent' ? 'accent' : ''
  return (
    <div>
      <div className="label">{label}</div>
      <div className={`num mt-2 leading-none tracking-[-0.04em] ${big ? 'text-[36px] sm:text-[44px]' : 'text-[26px] sm:text-[30px]'} font-medium ${color}`}>{value}</div>
      {sub && <div className="muted mt-1.5 text-[13px]">{sub}</div>}
    </div>
  )
}

/* Анимация ухода элемента перед удалением/выполнением.
   const [leaving, leave] = useLeave(); leave(id, 'done', () => api.delete(id)) → строка уезжает, потом выполняется действие */
export function useLeave(ms = 460) {
  const [map, setMap] = useState({})
  const leave = (id, kind, action) => {
    setMap((m) => ({ ...m, [id]: kind || 'leaving' }))
    return new Promise((res) => setTimeout(async () => {
      try { await action?.() } finally { setMap((m) => { const c = { ...m }; delete c[id]; return c }); res() }
    }, ms))
  }
  const cls = (id) => map[id] === 'done' ? 'leaving-done' : map[id] === 'card' ? 'leaving-card' : map[id] ? 'leaving' : ''
  return [cls, leave]
}

/* Подсветка только что появившихся элементов: сравнивает список id с прошлым рендером */
export function useArrived(ids) {
  const prev = useRef(null)
  const [fresh, setFresh] = useState(new Set())
  useEffect(() => {
    const cur = new Set(ids)
    if (prev.current) {
      const add = [...cur].filter((x) => !prev.current.has(x))
      if (add.length && add.length < 6) { setFresh(new Set(add)); const t = setTimeout(() => setFresh(new Set()), 1500); prev.current = cur; return () => clearTimeout(t) }
    }
    prev.current = cur
  }, [ids.join(',')]) // eslint-disable-line
  return (id) => fresh.has(id) ? 'arrived' : ''
}

/* Кнопка, которая на секунду становится зелёной галочкой после успешного действия */
export function useDoneFlash(ms = 1100) {
  const [on, setOn] = useState(false)
  const flash = () => { setOn(true); setTimeout(() => setOn(false), ms) }
  return [on ? 'btn-done' : '', flash]
}

/* ---------- уведомления: один глобальный стек (Toaster в App), страницы зовут useToast()/toast() ---------- */
const _toasts = { list: [], subs: new Set(), seq: 0 }
const _emit = () => _toasts.subs.forEach((f) => f([..._toasts.list]))
export function toast(title, { sub, kind = '', ms } = {}) {
  const id = ++_toasts.seq
  _toasts.list = [..._toasts.list.slice(-3), { id, title, sub, kind }]
  _emit()
  setTimeout(() => { _toasts.list = _toasts.list.map((t) => (t.id === id ? { ...t, out: true } : t)); _emit() }, ms || (kind === 'err' ? 4200 : 2600))
  setTimeout(() => { _toasts.list = _toasts.list.filter((t) => t.id !== id); _emit() }, (ms || (kind === 'err' ? 4200 : 2600)) + 240)
  return id
}
export function Toaster() {
  const [list, setList] = useState([])
  useEffect(() => { _toasts.subs.add(setList); return () => _toasts.subs.delete(setList) }, [])
  if (!list.length) return null
  return createPortal(
    <div className="pointer-events-none fixed inset-x-3 top-3 z-[120] flex flex-col items-center gap-2 sm:inset-x-auto sm:bottom-6 sm:right-6 sm:top-auto sm:items-end">
      {list.map((t) => (
        <div key={t.id} className={`toast toast-in ${t.kind} ${t.out ? 'out' : ''}`}>
          <span className="toast-ic">{t.kind === 'err' ? <X size={14} /> : <Check size={14} />}</span>
          <div className="min-w-0">
            <div className="font-medium leading-snug">{t.title}</div>
            {t.sub && <div className="muted mt-0.5 text-[12.5px] leading-snug">{t.sub}</div>}
          </div>
        </div>
      ))}
    </div>,
    document.body
  )
}
/* обратная совместимость: страницы рендерят <Toast {...toast} /> — теперь это ничего не рисует, всё идёт через Toaster */
export function Toast() { return null }
export function useToast() {
  const [t] = useState({ msg: '', kind: '' })
  const show = (msg, kind = '', sub) => { if (msg) toast(msg, { kind: kind === 'err' ? 'err' : kind || 'ok', sub }) }
  show.err = (e) => show(typeof e === 'string' ? e : (e?.message || 'Ошибка'), 'err')
  return [t, show]
}

/* Переключатель да/нет */
export function Switch({ on, onChange, label }) {
  return (
    <button type="button" role="switch" aria-checked={!!on} aria-label={label} className={`switch ${on ? 'on' : ''}`} onClick={() => onChange(!on)} />
  )
}

export function Skeleton({ h = 80, className = '' }) {
  return <div className={`fill animate-pulseSoft rounded-2xl ${className}`} style={{ height: h }} />
}
/* Скелет списка: N строк как в реальном списке */
export function ListSkeleton({ n = 4 }) {
  return <div className="space-y-3 py-2">{Array.from({ length: n }, (_, i) => <div key={i} className="flex items-center gap-3"><div className="fill animate-pulseSoft h-6 w-6 rounded-full" /><div className="fill animate-pulseSoft h-4 rounded-md" style={{ width: `${45 + ((i * 17) % 40)}%` }} /></div>)}</div>
}

/* Подтверждение вместо window.confirm */
export function Confirm({ open, title, text, onOk, onClose, danger }) {
  return (
    <Sheet open={open} onClose={onClose} title={title}>
      {text && <div className="muted mb-5 text-[14px] leading-relaxed">{text}</div>}
      <div className="flex gap-2">
        <button className="btn-ghost flex-1" onClick={onClose}>Отмена</button>
        <button className={`btn-primary flex-1 ${danger ? '!bg-red' : ''}`} style={danger ? { background: 'var(--neg)' } : {}} onClick={onOk}>Да</button>
      </div>
    </Sheet>
  )
}

export const PRIORITY = { 1: { dot: 'bg-red', label: 'Важно', cls: 'neg' }, 2: { dot: 'bg-orange', label: 'Обычная', cls: 'warn' }, 3: { dot: 'bg-green', label: 'Низкая', cls: 'pos' } }

/* Точка приоритета → всплывающий выбор. Рисуется через портал в body: строки задач лежат внутри
   .swipe с overflow:hidden, и обычный absolute-попап там просто обрезался. */
export function PriorityDot({ value, onChange, disabled }) {
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState(null)
  const btn = useRef(null)
  const toggle = () => {
    if (disabled) return
    if (open) return setOpen(false)
    const r = btn.current.getBoundingClientRect()
    const left = Math.min(r.right - 152, window.innerWidth - 160)
    const below = r.bottom + 6 + 120 < window.innerHeight
    setPos({ left: Math.max(8, left), top: below ? r.bottom + 6 : undefined, bottom: below ? undefined : window.innerHeight - r.top + 6 })
    setOpen(true)
  }
  useEffect(() => {
    if (!open) return
    const h = (e) => { if (!btn.current?.contains(e.target) && !e.target.closest?.('[data-pr-menu]')) setOpen(false) }
    const k = (e) => e.key === 'Escape' && setOpen(false)
    const s = () => setOpen(false)
    document.addEventListener('mousedown', h); document.addEventListener('touchstart', h, { passive: true }); document.addEventListener('keydown', k); window.addEventListener('scroll', s, true)
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('touchstart', h); document.removeEventListener('keydown', k); window.removeEventListener('scroll', s, true) }
  }, [open])
  return (
    <>
      <button ref={btn} type="button" className="btn-icon !h-7 !w-7" data-tip={open ? undefined : PRIORITY[value]?.label} onClick={toggle} aria-label="Приоритет" aria-expanded={open}>
        <span className={`h-2 w-2 rounded-full ${PRIORITY[value]?.dot}`} />
      </button>
      {open && pos && createPortal(
        <div data-pr-menu className="elevated fixed z-[120] w-[152px] !p-1" style={{ left: pos.left, top: pos.top, bottom: pos.bottom, animation: 'rise .16s var(--ease-out)' }}>
          <div className="label px-2.5 pb-1 pt-1.5 !text-[10px]">важность</div>
          {[1, 2, 3].map((p) => (
            <button key={p} type="button" className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-[13px] hover:bg-[var(--fill)] ${p === value ? 'font-medium' : ''}`} onClick={() => { setOpen(false); if (p !== value) onChange(p) }}>
              <span className={`h-2 w-2 rounded-full ${PRIORITY[p].dot}`} />{PRIORITY[p].label}{p === value && <Check size={12} className="ml-auto text-accent" />}
            </button>
          ))}
        </div>, document.body)}
    </>
  )
}
