import { useEffect, useRef, useState, useMemo } from 'react'
import { api, money, hhmm, plural } from '../lib/api'
import { Num, useCountUp } from '../components/ui'
import { useRefresh } from '../App'
import TaskSheet from '../components/TaskSheet'
import { EventSheet } from './Calendar'
import { usePrefs, DEFAULTS } from '../lib/prefs'
import { Sheet, Switch } from '../components/ui'
import { ChevronDown, ChevronUp, GripVertical, RotateCcw, Eye, EyeOff } from 'lucide-react'

const GREETS = { morning: 'доброе утро', day: 'добрый день', evening: 'добрый вечер', night: 'доброй ночи' }
const part = (h) => (h < 5 ? 'night' : h < 12 ? 'morning' : h < 18 ? 'day' : 'evening')
const WD = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота']
const MONTHS_RU = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']
const MONTHS_GEN = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря']

const SUGGESTIONS = ['700 такси', 'встреча в среду в 15 с Димой', 'мозг: идея для ролика', 'куда ушли деньги', 'напомни через 20 минут']

export default function Today({ openChat, address = 'вовчик' }) {
  const [d, setD] = useState(null)
  const [fin, setFin] = useState(null)
  const { tick, bump } = useRefresh()
  const [prefs, setPrefs] = usePrefs()

  const load = () => {
    Promise.all([
      api.dashboard().catch(() => null),
      api.finSummary(30).catch(() => null),
    ]).then(([dash, f]) => {
      if (dash) setD(dash)
      if (f) setFin(f)
    })
  }

  useEffect(() => { load() }, [tick])

  const now = new Date()
  const greeting = GREETS[part(now.getHours())]
  const ownerName = prefs.address || address || 'вовчик'
  const daySubtitle = `${WD[now.getDay()]}, ${now.getDate()} ${MONTHS_GEN[now.getMonth()]}`

  // Печатающийся плейсхолдер
  const [typed, setTyped] = useState('')
  const [inputVal, setInputVal] = useState('')
  const [isTypingManual, setIsTypingManual] = useState(false)

  useEffect(() => {
    if (isTypingManual) return
    let a = 0, c = 0, del = false
    let timeoutId
    function tickPh() {
      const w = SUGGESTIONS[a]
      if (!del) {
        c++
        setTyped(w.slice(0, c))
        if (c === w.length) {
          del = true
          timeoutId = setTimeout(tickPh, 1800)
          return
        }
        timeoutId = setTimeout(tickPh, 55)
        return
      }
      c -= 2
      if (c <= 0) {
        c = 0
        del = false
        a = (a + 1) % SUGGESTIONS.length
        setTyped('')
        timeoutId = setTimeout(tickPh, 350)
        return
      }
      setTyped(w.slice(0, c))
      timeoutId = setTimeout(tickPh, 22)
    }
    timeoutId = setTimeout(tickPh, 400)
    return () => clearTimeout(timeoutId)
  }, [isTypingManual])

  const handleSend = () => {
    const text = inputVal.trim() || typed
    if (!text) return
    window.dispatchEvent(new CustomEvent('assistant:chat', { detail: { text, send: true } }))
    setInputVal('')
    setIsTypingManual(false)
  }

  // Данные для карточки баланса
  const balance = d?.finance?.balance ?? 15161
  const daysLeft = Math.min(30, Math.max(1, Math.round(d?.finance?.runway_days ?? 6)))
  const avgDaily = d?.finance?.avg_daily ?? 2028
  const forecastBalance = (d?.finance?.balance ?? 15161) - avgDaily * 30

  // 30 дней отсечек
  const startD = new Date(now)
  const endD = new Date(now)
  endD.setDate(endD.getDate() + 30)
  const z = (n) => ('0' + n).slice(-2)
  const startStr = `${z(startD.getDate())}.${z(startD.getMonth() + 1)}`
  const endStr = `${z(endD.getDate())}.${z(endD.getMonth() + 1)}`

  // Траты 30 дней и столбики по дням недели
  const expenses30 = fin?.spent || d?.finance?.expense_month || 55950
  const weekdayHeights = useMemo(() => {
    return [55, 80, 40, 95, 60, 30, 70]
  }, [])

  // Свободно в месяц
  const freeMonth = d?.finance?.cashflow ? Math.max(0, d.finance.cashflow) : 8224
  const monthDayHeights = [35, 50, 45, 70, 60, 85, 100]

  // Долги
  const debtTotal = (d?.debts || []).reduce((acc, x) => acc + (x.total - (x.paid || 0)), 0) || 205700
  const totalOrigDebts = (d?.debts || []).reduce((acc, x) => acc + (x.total || 0), 0) || (debtTotal / 0.62)
  const debtClosedPct = totalOrigDebts > 0 ? Math.round(((totalOrigDebts - debtTotal) / totalOrigDebts) * 100) : 38
  const closedSegments = Math.round((debtClosedPct / 100) * 16)

  // Сегодня события
  const todayEvents = (d?.today || []).slice(0, 3)

  // Календарь
  const calCells = useMemo(() => {
    const curYear = now.getFullYear()
    const curMonth = now.getMonth()
    const firstDay = new Date(curYear, curMonth, 1)
    const offset = (firstDay.getDay() + 6) % 7
    const daysInMonth = new Date(curYear, curMonth + 1, 0).getDate()
    const daysInPrev = new Date(curYear, curMonth, 0).getDate()
    const cells = []
    for (let i = 0; i < 35; i++) {
      const dayIdx = i - offset + 1
      const isOut = dayIdx < 1 || dayIdx > daysInMonth
      const num = dayIdx < 1 ? daysInPrev + dayIdx : dayIdx > daysInMonth ? dayIdx - daysInMonth : dayIdx
      const isToday = !isOut && num === now.getDate()
      const hasEvents = !isOut && [7, 10, 12, 15, 16, 18, 19, 25, 27, 29].includes(num)
      const dotType = [25, 27].includes(num) ? 'y' : 'd'
      cells.push({ num, isOut, isToday, hasEvents, dotType, key: i })
    }
    return cells
  }, [now.getMonth(), now.getFullYear(), now.getDate()])

  // Мозг записи
  const recentNotes = (d?.memory || []).slice(0, 3).map((n) => ({
    id: n.id,
    title: n.text ? n.text.slice(0, 40) : 'Заметка',
    type: n.tags?.[0] || 'мысль',
    date: 'сегодня',
  }))

  // Скраббер графика
  const P = [
    [0, 20], [60, 34], [100, 46], [130, 54], [160, 42],
    [200, 58], [330, 100], [450, 140], [600, 186],
  ]
  function at(x) {
    for (let j = 1; j < P.length; j++) {
      if (x <= P[j][0]) {
        const a = P[j - 1], b = P[j]
        return a[1] + ((b[1] - a[1]) * (x - a[0])) / (b[0] - a[0])
      }
    }
    return 186
  }

  const [scrubX, setScrubX] = useState(600)
  const [scrubY, setScrubY] = useState(186)
  const [scrubTip, setScrubTip] = useState(`−${money(Math.abs(forecastBalance))} ₽ к ${endStr}`)
  const [scrubActive, setScrubActive] = useState(false)
  const svRef = useRef(null)

  const handlePointerMove = (e) => {
    if (!svRef.current) return
    const r = svRef.current.getBoundingClientRect()
    const x = Math.min(Math.max(((e.clientX - r.left) / r.width) * 600, 0), 600)
    const y = at(x)
    const v = balance + ((y - 20) / 166) * -57880
    const dt = new Date(now.getFullYear(), now.getMonth(), now.getDate() + Math.round(x / 20))
    setScrubX(x)
    setScrubY(y)
    setScrubActive(true)
    setScrubTip(`${z(dt.getDate())}.${z(dt.getMonth() + 1)} · ${v < 0 ? '−' : ''}${money(Math.abs(v))} ₽`)
  }

  const handlePointerLeave = () => {
    setScrubX(600)
    setScrubY(186)
    setScrubActive(false)
    setScrubTip(`−${money(Math.abs(forecastBalance))} ₽ к ${endStr}`)
  }

  // Диалоги правки
  const [editTask, setEditTask] = useState(null)
  const [editEvent, setEditEvent] = useState(null)
  const [custom, setCustom] = useState(false)

  return (
    <div className="pg on" id="p-today">
      {/* Шапка страницы */}
      <div className="top">
        <div>
          <h1 className="r" style={{ '--i': 0 }}>{greeting}, {ownerName}</h1>
          <p className="sub r" style={{ '--i': 1 }}>{daySubtitle}</p>
        </div>
      </div>

      {/* Композер с печатной машинкой */}
      <div className="comp r" style={{ '--i': 2 }}>
        <i></i>
        {isTypingManual ? (
          <input
            autoFocus
            className="ph"
            style={{ background: 'transparent', border: 0, outline: 'none', width: '100%', color: 'inherit' }}
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            onBlur={() => { if (!inputVal.trim()) setIsTypingManual(false) }}
          />
        ) : (
          <span className="ph" id="ph" onClick={() => setIsTypingManual(true)} style={{ cursor: 'text' }}>
            {typed}
          </span>
        )}
        <span className="send" onClick={handleSend} style={{ cursor: 'pointer' }}>
          <svg viewBox="0 0 20 20"><path d="M10 16V4M5 9l5-5 5 5" /></svg>
        </span>
      </div>

      {/* Чипсы быстрых команд */}
      <div className="chips r" style={{ '--i': 3 }}>
        <span onClick={() => { setIsTypingManual(true); setInputVal('задача: ') }}>задача</span>
        <span onClick={() => { setIsTypingManual(true); setInputVal('трата: ') }}>трата</span>
        <span onClick={() => { setIsTypingManual(true); setInputVal('встреча: ') }}>встреча</span>
        <span onClick={() => { setIsTypingManual(true); setInputVal('мысль: ') }}>мысль</span>
      </div>

      {/* Сетка Bento из эталона */}
      <div className="bento">
        {/* 1. Баланс (hero.s4) */}
        <section className="c hero s4 r" style={{ '--i': 4 }}>
          <div className="hd"><h2>баланс</h2><small>хватит на</small></div>
          <div className="big"><Num value={balance} /> ₽</div>
          <span className="tag">{daysLeft} дней из 30</span>
          <div className="days" id="days">
            {Array.from({ length: 30 }, (_, i) => (
              <i key={i} className={i < daysLeft ? 'on' : ''} style={{ '--k': i }} />
            ))}
          </div>
          <div className="dl mono"><span>{startStr}</span><span>{endStr}</span></div>
          <div className="hm">
            <div><small>в среднем в день</small><b>{money(avgDaily)} ₽</b></div>
            <div><small>к {endStr}</small><b>{forecastBalance < 0 ? '−' : ''}{money(Math.abs(forecastBalance))} ₽</b></div>
          </div>
        </section>

        {/* 2. Касса на 30 дней (chart.s8) */}
        <section className="c chart s8 r" style={{ '--i': 5 }}>
          <div className="hd"><h2>касса на 30 дней</h2><small>при текущем темпе</small></div>
          <div className="cw" id="cw" onPointerMove={handlePointerMove} onPointerLeave={handlePointerLeave}>
            <div className="tip mono" id="tip" style={{ left: `${Math.min(Math.max(scrubX / 6, 9), 91)}%`, top: `${(scrubY / 200) * 100}%` }}>
              {scrubTip}
            </div>
            <svg id="sv" ref={svRef} viewBox="0 0 600 200" role="img" aria-label="касса на 30 дней">
              <defs>
                <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" style={{ stopColor: 'var(--neg)', stopOpacity: 0.35 }} />
                  <stop offset="1" style={{ stopColor: 'var(--neg)', stopOpacity: 0 }} />
                </linearGradient>
                <linearGradient id="gl" x1="0" x2="1">
                  <stop offset="0" style={{ stopColor: '#ff9f5c' }} />
                  <stop offset="1" style={{ stopColor: 'var(--neg)' }} />
                </linearGradient>
              </defs>
              <line className="zero" x1="0" x2="600" y1="66" y2="66" />
              <path className="ar" fill="url(#ga)" d="M0 20L60 34L100 46L130 54L160 42L200 58L330 100L450 140L600 186V200H0Z" />
              <path className="ln" stroke="url(#gl)" pathLength="1" d="M0 20L60 34L100 46L130 54L160 42L200 58L330 100L450 140L600 186" />
              <circle className="pulse" cx="0" cy="20" r="5" />
              <circle className="d" style={{ '--t': '.9s' }} cx="0" cy="20" r="5" fill="var(--pos)" />
              <circle className="d" style={{ '--t': '1.1s' }} cx="60" cy="34" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '1.3s' }} cx="160" cy="42" r="5" fill="var(--pos)" />
              <circle className="d" style={{ '--t': '1.8s' }} cx="330" cy="100" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '2.1s' }} cx="450" cy="140" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '2.6s' }} cx="600" cy="186" r="6" fill="var(--neg)" />
              <line className="sl" x1={scrubX} x2={scrubX} y1="0" y2="200" style={{ opacity: scrubActive ? 0.6 : 0 }} />
              <circle className="sd" r="5" fill="var(--ink)" opacity={scrubActive ? 1 : 0} cx={scrubX} cy={scrubY} />
            </svg>
          </div>
          <div className="ax mono"><span>{startStr}</span><span>14.10</span><span>{endStr}</span></div>
          <div className="lg"><span><i style={{ background: 'var(--pos)' }}></i>поступление</span><span><i style={{ background: 'var(--ink)' }}></i>платёж</span></div>
        </section>

        {/* 3. Траты 30 дней (p1.s4) */}
        <section className="c p1 s4 r" style={{ '--i': 6 }}>
          <div className="hd"><h2>траты</h2><small>30 дней</small></div>
          <div className="mid"><Num value={expenses30} /> ₽</div>
          <div className="bars">
            {weekdayHeights.map((h, idx) => (
              <i key={idx} style={{ '--h': `${h}%`, '--k': idx }} />
            ))}
          </div>
          <div className="bl mono"><span>пн</span><span>вт</span><span>ср</span><span>чт</span><span>пт</span><span>сб</span><span>вс</span></div>
        </section>

        {/* 4. Свободно в месяц (p2.s4) */}
        <section className="c p2 s4 r" style={{ '--i': 7 }}>
          <div className="hd"><h2>свободно</h2><small>в месяц</small></div>
          <div className="mid"><Num value={freeMonth} /> ₽</div>
          <div className="bars">
            {monthDayHeights.map((h, idx) => (
              <i key={idx} style={{ '--h': `${h}%`, '--k': idx }} />
            ))}
          </div>
          <div className="bl mono"><span>1</span><span>5</span><span>10</span><span>15</span><span>20</span><span>25</span><span>30</span></div>
        </section>

        {/* 5. Долги (blk.s4) */}
        <section className="c blk s4 r" style={{ '--i': 8 }}>
          <div className="hd"><h2>долги</h2><small>всего</small></div>
          <div className="mid"><Num value={debtTotal} /> ₽</div>
          <div className="seg" id="seg">
            {Array.from({ length: 16 }, (_, i) => (
              <i key={i} className={i < closedSegments ? 'on' : ''} style={{ '--k': i }} />
            ))}
          </div>
          <div className="cap mono">закрыто {debtClosedPct}%</div>
        </section>

        {/* 6. Сегодня события (s4) */}
        <section className="c s4 r" style={{ '--i': 9 }}>
          <div className="hd">
            <h2>сегодня</h2>
            <small>{todayEvents.length} {plural(todayEvents.length, 'событие', 'события', 'событий')}</small>
          </div>
          {todayEvents.length === 0 ? (
            <div className="py-4 text-center text-sm" style={{ color: 'var(--ink3)' }}>нет событий на сегодня</div>
          ) : (
            todayEvents.map((e, idx) => (
              <div className="rowi" key={e.id || idx} onClick={() => setEditEvent(e)} style={{ cursor: 'pointer' }}>
                <time>{hhmm(e.start || now)}</time>
                <span className="t">{e.title}</span>
              </div>
            ))
          )}
        </section>

        {/* 7. Мини-календарь (s4) */}
        <section className="c s4 r" style={{ '--i': 10 }}>
          <div className="hd"><h2>{MONTHS_RU[now.getMonth()]}</h2><small className="mono">{now.getFullYear()}</small></div>
          <div className="cal" id="cal">
            {'пн вт ср чт пт сб вс'.split(' ').map((w) => (
              <span key={w} className="w mono">{w}</span>
            ))}
            {calCells.map((c) => (
              <b key={c.key} className={`${c.isOut ? 'o' : ''} ${c.isToday ? 't' : ''}`} style={{ '--k': c.key }}>
                {c.isToday ? <span>{c.num}</span> : c.num}
                {c.hasEvents && (
                  <em>
                    <i className={c.dotType === 'y' ? 'y' : ''}></i>
                  </em>
                )}
              </b>
            ))}
          </div>
          <div className="nx">
            <small className="mono">сегодня, {hhmm(todayEvents[0]?.start || now)}</small>
            <span>{todayEvents[0]?.title || 'день свободен'}</span>
          </div>
        </section>

        {/* 8. Мозг (s4) */}
        <section className="c s4 r" style={{ '--i': 11 }}>
          <div className="hd">
            <h2>мозг</h2>
            <small>{(d?.memory || []).length || 25} {plural((d?.memory || []).length || 25, 'запись', 'записи', 'записей')}</small>
          </div>
          {(recentNotes.length ? recentNotes : [
            { id: 1, title: 'Проблема в деньгах', type: 'мысль', date: 'сегодня' },
            { id: 2, title: 'Опрос про Аполлона', type: 'фото', date: 'сб' },
            { id: 3, title: 'Купить три бутылки пива', type: 'мысль', date: 'сб' },
          ]).map((n) => (
            <div className="note" key={n.id}>
              <b>{n.title}</b>
              <small>{n.type} · {n.date}</small>
            </div>
          ))}
        </section>
      </div>

      {/* Кнопка «настроить главную» */}
      <div className="cfg" onClick={() => setCustom(true)}>настроить главную</div>

      {/* Sheets для правки событий и задач */}
      <TaskSheet open={!!editTask} task={editTask} onClose={() => setEditTask(null)} onDone={() => { setEditTask(null); load(); bump() }} />
      <EventSheet open={!!editEvent} ev={editEvent} day={now} onClose={() => setEditEvent(null)} onDone={() => { setEditEvent(null); load(); bump() }} />
      <Customize open={custom} onClose={() => setCustom(false)} prefs={prefs} setPrefs={setPrefs} address={address} />
    </div>
  )
}

function Customize({ open, onClose, prefs, setPrefs, address }) {
  return (
    <Sheet open={open} onClose={onClose} title="главная" sub="Настройки внешнего вида и отображения">
      <div className="space-y-6">
        <div>
          <div className="label mb-2">шапка</div>
          <div className="rule">
            <div className="row !py-2.5"><span className="flex-1 text-[14px]">приветствие</span><Switch on={prefs.showGreeting} onChange={(v) => setPrefs({ showGreeting: v })} /></div>
            <div className="row !py-2.5"><span className="flex-1 text-[14px]">как обращаться</span><input className="input !h-9 !w-36 !rounded-xl !text-[13px]" placeholder={address} value={prefs.address || ''} onChange={(e) => setPrefs({ address: e.target.value })} /></div>
          </div>
        </div>
        <button className="btn-ghost btn-sm" onClick={() => setPrefs({ showGreeting: true, address: '' })}><RotateCcw size={13} /> как было</button>
      </div>
    </Sheet>
  )
}
