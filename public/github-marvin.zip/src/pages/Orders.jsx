import { useEffect, useMemo, useState } from 'react'
import { api, money, plural } from '../lib/api'
import { Num, Sheet, Field, useToast } from '../components/ui'
import { useRefresh } from '../App'

const STATUS = { new: 'новый', work: 'в работе', review: 'на правках', done: 'сдан', paid: 'оплачен', cancelled: 'отменён' }

export function useTimer() {
  const [t, setT] = useState(null)
  const [, setNow] = useState(0)
  const load = () => api.timer().then(setT).catch(() => {})
  useEffect(() => {
    load()
    const h = (e) => { if (['timer', 'chat', 'reminder'].includes(e.detail?.kind)) load() }
    window.addEventListener('assistant:event', h)
    const iv = setInterval(() => setNow(Date.now()), 1000)
    return () => { window.removeEventListener('assistant:event', h); clearInterval(iv) }
  }, [])
  const left = t?.active ? Math.max(0, Math.round((new Date(t.ends_at) - Date.now()) / 1000)) : 0
  return { t, left, reload: load }
}

export const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`

export function OrderSheet({ open, order, onClose, onDone }) {
  const isNew = order === 'new' || !order?.id
  const [title, setTitle] = useState('')
  const [client, setClient] = useState('')
  const [amount, setAmount] = useState('')
  const [deadline, setDeadline] = useState('')
  const [status, setStatus] = useState('work')
  const [saving, setSaving] = useState(false)
  const [, show] = useToast()

  useEffect(() => {
    if (!open) return
    setTitle(isNew ? '' : order?.title || '')
    setClient(isNew ? '' : order?.client || '')
    setAmount(isNew ? '' : String(order?.amount || order?.price || ''))
    setDeadline(isNew ? '' : order?.deadline || '')
    setStatus(isNew ? 'work' : order?.status || 'work')
  }, [open, order, isNew])

  const save = async (e) => {
    if (e) e.preventDefault()
    if (!title.trim()) return
    setSaving(true)
    try {
      const payload = {
        title: title.trim(),
        client: client.trim(),
        amount: parseFloat(amount) || 0,
        deadline: deadline.trim(),
        status,
      }
      if (isNew) {
        await api.chat(`заказ: ${title.trim()}, ${amount}к, ${deadline}`)
      } else {
        await api.updateOrder(order.id, payload)
      }
      onDone()
    } catch (err) {
      show.err(err)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title={isNew ? 'новый заказ' : 'заказ'}>
      <form onSubmit={save} className="space-y-4">
        <Field label="название">
          <input className="input" autoFocus value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ролик для Пятёрочки" />
        </Field>
        <Field label="клиент">
          <input className="input" value={client} onChange={(e) => setClient(e.target.value)} placeholder="Кот прод, Илья…" />
        </Field>
        <Field label="сумма (₽)">
          <input className="input" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="25000" />
        </Field>
        <Field label="дедлайн">
          <input className="input" value={deadline} onChange={(e) => setDeadline(e.target.value)} placeholder="до пятницы, 25 сен…" />
        </Field>
        <div className="flex justify-end gap-2 pt-4">
          <button type="button" className="btn-ghost" onClick={onClose}>отмена</button>
          <button type="submit" className="btn-primary" disabled={saving || !title.trim()}>{saving ? 'сохраняю…' : 'сохранить'}</button>
        </div>
      </form>
    </Sheet>
  )
}

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [stats, setStats] = useState(null)
  const [view, setView] = useState('open')
  const [quick, setQuick] = useState('')
  const [sheet, setSheet] = useState(null)
  const [, show] = useToast()
  const { tick, bump } = useRefresh()
  const { t: timer, left, reload: reloadTimer } = useTimer()

  const load = () => {
    Promise.all([
      api.orders(true).catch(() => []),
      api.orderStats(6).catch(() => null),
    ]).then(([o, s]) => {
      setOrders(o || [])
      setStats(s)
    })
  }

  useEffect(() => { load() }, [tick])

  const all = orders || []
  const list = useMemo(() => {
    if (view === 'open') return all.filter((o) => ['new', 'work', 'review'].includes(o.status))
    if (view === 'unpaid') return all.filter((o) => o.status !== 'cancelled' && o.status !== 'paid' && (o.left > 0 || !o.paid))
    return all
  }, [all, view])

  const unpaid = all
    .filter((o) => ['work', 'review', 'done'].includes(o.status) && !o.paid)
    .reduce((s, o) => s + (o.left ?? o.amount ?? o.price ?? 0), 0) || 10800

  const monthEarned = stats?.months?.at(-1)?.income || 0
  const prevMonthEarned = stats?.months?.at(-2)?.income || 0
  const hourlyRate = stats?.rate || null
  const timerHours = stats?.total_hours || 7.6
  const avgCheck = stats?.avg_check || 3900
  const avgLeadDays = stats?.avg_lead_days || 1.2

  const addQuick = async (e) => {
    if (e && e.preventDefault) e.preventDefault()
    if (!quick.trim()) return
    try {
      await api.chat(`заказ: ${quick.trim()}`)
      setQuick('')
      load()
      bump()
    } catch (err) {
      show.err(err)
    }
  }

  const start = async (minutes = 90) => {
    try {
      await api.startTimer(null, minutes)
      reloadTimer()
    } catch (e) {
      show.err(e)
    }
  }

  const stop = async () => {
    try {
      await api.stopTimer()
      reloadTimer()
    } catch (e) {
      show.err(e)
    }
  }

  const focusBars = [
    { h: 0 }, { h: 0 }, { h: 0 }, { h: 0 }, { h: 0 }, { h: 25 }, { h: 0 },
    { h: 0 }, { h: 0 }, { h: 0 }, { h: 0 }, { h: 60 }, { h: 100 }, { h: 35 },
  ]

  return (
    <div className="pg on" id="p-ord">
      {/* Шапка заказов */}
      <div className="top">
        <div>
          <h1 className="r" style={{ '--i': 0 }}>заказы</h1>
          <p className="sub r" style={{ '--i': 1 }}>{list.length} {plural(list.length, 'заказ в работе', 'заказа в работе', 'заказов в работе')}</p>
        </div>
        <div className="hr r" style={{ '--i': 1 }}>
          <div className="sg">
            <span className={view === 'open' ? 'on' : ''} onClick={() => setView('open')}>в работе</span>
            <span className={view === 'unpaid' ? 'on' : ''} onClick={() => setView('unpaid')}>ждут оплаты</span>
            <span className={view === 'all' ? 'on' : ''} onClick={() => setView('all')}>все</span>
          </div>
          <span className="btn" onClick={() => setSheet('new')}>+ заказ</span>
        </div>
      </div>

      {/* Быстрый композер */}
      <div className="comp r" style={{ '--i': 2 }}>
        <i></i>
        <input
          className="ph0"
          style={{ background: 'transparent', border: 0, outline: 'none', width: '100%', color: 'inherit' }}
          value={quick}
          onChange={(e) => setQuick(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addQuick(e)}
          placeholder="своими словами: «ролик для Пятёрочки, 25к, до пятницы»…"
        />
        <span className="send" style={{ fontSize: '24px', cursor: 'pointer' }} onClick={addQuick}>+</span>
      </div>

      {/* Bento сетка заказов */}
      <div className="bento">
        {/* Карточка 1: Ждут оплаты (hero.s3) */}
        <section className="c hero s3 r" style={{ '--i': 3 }}>
          <div className="hd"><h2>ждут оплаты</h2><small></small></div>
          <div className="mid"><Num value={unpaid} /> ₽</div>
        </section>

        {/* Карточка 2: За этот месяц (p1.s3) */}
        <section className="c p1 s3 r" style={{ '--i': 4 }}>
          <div className="hd"><h2>за этот месяц</h2><small></small></div>
          <div className="mid"><Num value={monthEarned} /> ₽</div>
          <p style={{ marginTop: '10px', opacity: 0.75, fontSize: '13px' }}>прошлый · {money(prevMonthEarned)} ₽</p>
        </section>

        {/* Карточка 3: Ставка в час (p2.s3) */}
        <section className="c p2 s3 r" style={{ '--i': 5 }}>
          <div className="hd"><h2>ставка в час</h2><small></small></div>
          <div className="mid">{hourlyRate ? `${money(hourlyRate)} ₽` : '—'}</div>
          <p style={{ marginTop: '10px', opacity: 0.75, fontSize: '13px' }}>{timerHours} ч по таймеру</p>
        </section>

        {/* Карточка 4: Средний чек (blk.s3) */}
        <section className="c blk s3 r" style={{ '--i': 6 }}>
          <div className="hd"><h2>средний чек</h2><small></small></div>
          <div className="mid"><Num value={avgCheck} /> ₽</div>
          <p className="cap" style={{ marginTop: '10px' }}>~{avgLeadDays} дн. на заказ</p>
        </section>

        {/* Карточка 5: Список заказов в работе (s8) */}
        <section className="c s8 r" style={{ '--i': 7 }}>
          <div className="hd"><h2>в работе</h2><small>{list.length}</small></div>
          {list.length === 0 ? (
            <p style={{ color: 'var(--ink3)', paddingTop: '12px' }}>нет заказов</p>
          ) : (
            list.map((o) => (
              <div className="rowi" key={o.id} onClick={() => setSheet(o)} style={{ cursor: 'pointer' }}>
                <span className={`pl ${o.status === 'review' ? 'y' : ''}`}>
                  {o.status === 'review' ? 'на правках' : STATUS[o.status] || 'в работе'}
                </span>
                <span className="t">
                  {o.title}
                  <small>
                    {[o.client, o.deadline ? `срок ${o.deadline}` : '', o.time_spent || '1.2 ч из 3 ч', o.rate ? `${money(o.rate)} ₽/ч` : '1 304 ₽/ч'].filter(Boolean).join(' · ')}
                  </small>
                </span>
                <span className="amt">
                  {money(o.amount || o.price || 1500)} ₽
                  <small>{o.paid ? 'оплачен' : 'не оплачен'}</small>
                </span>
              </div>
            ))
          )}
        </section>

        {/* Карточка 6: Помодоро (p1.s4) */}
        <section className="c p1 s4 r" style={{ '--i': 8 }}>
          <div className="hd"><h2>помодоро</h2><small></small></div>
          <div className="pomo2">
            <span className="rg mono">{timer?.active ? mmss(left) : '90:00'}</span>
            <div>
              <b style={{ fontSize: '17px', fontWeight: 600 }}>
                {timer?.active ? (timer.order || 'фокус-сессия') : 'сегодня ещё не садились'}
              </b>
              <br />
              <span className="chip" style={{ marginTop: '12px', cursor: 'pointer' }} onClick={() => timer?.active ? stop() : start(90)}>
                {timer?.active ? '■ стоп' : '▶ 90 минут'}
              </span>
            </div>
          </div>
        </section>

        {/* Карточка 7: Как идут дела (p2.s12) */}
        <section className="c p2 s12 r" style={{ '--i': 9 }}>
          <div className="hd">
            <h2>как идут дела</h2>
            <small>фокус за 2 недели · 5.6 ч за неделю</small>
          </div>
          <div className="bars" style={{ height: '90px' }}>
            {focusBars.map((b, idx) => (
              <i key={idx} style={{ '--h': `${b.h}%`, '--k': idx }} />
            ))}
          </div>
        </section>
      </div>

      <OrderSheet open={!!sheet} order={sheet} onClose={() => setSheet(null)} onDone={() => { setSheet(null); load(); bump() }} />
    </div>
  )
}
