import { useEffect, useMemo, useState } from 'react'
import { api, hhmm, MONTHS_NOM, isSameDay, toLocalISO, dayLabel, shortDate, plural } from '../lib/api'
import { Sheet, Field, useToast } from '../components/ui'
import { useRefresh } from '../App'

const WD = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб']

export function EventSheet({ open, ev, day, onClose, onDone }) {
  const isNew = ev === 'new' || !ev?.id
  const [title, setTitle] = useState('')
  const [start, setStart] = useState('')
  const [saving, setSaving] = useState(false)
  const [, show] = useToast()

  useEffect(() => {
    if (!open) return
    setTitle(isNew ? '' : ev?.title || '')
    const d = isNew ? (day || new Date()) : new Date(ev?.start || Date.now())
    setStart(toLocalISO(d).slice(0, 16))
  }, [open, ev, day, isNew])

  const save = async (e) => {
    if (e) e.preventDefault()
    if (!title.trim()) return
    setSaving(true)
    try {
      if (isNew) {
        await api.addEvent({ title: title.trim(), start: new Date(start).toISOString() })
      } else {
        await api.patchEvent(ev.id, { title: title.trim(), start: new Date(start).toISOString() })
      }
      onDone()
    } catch (err) {
      show.err(err)
    } finally {
      setSaving(false)
    }
  }

  const remove = async () => {
    if (!ev?.id) return
    try {
      await api.delEvent(ev.id)
      onDone()
    } catch (err) {
      show.err(err)
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title={isNew ? 'новое событие' : 'событие'}>
      <form onSubmit={save} className="space-y-4">
        <Field label="название">
          <input className="input" autoFocus value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Встреча с клиентом" />
        </Field>
        <Field label="дата и время">
          <input type="datetime-local" className="input" value={start} onChange={(e) => setStart(e.target.value)} />
        </Field>
        <div className="flex items-center justify-between pt-4">
          {!isNew && <button type="button" className="btn-ghost !text-neg" onClick={remove}>удалить</button>}
          <div className="ml-auto flex gap-2">
            <button type="button" className="btn-ghost" onClick={onClose}>отмена</button>
            <button type="submit" className="btn-primary" disabled={saving || !title.trim()}>{saving ? 'сохраняю…' : 'сохранить'}</button>
          </div>
        </div>
      </form>
    </Sheet>
  )
}

export default function Calendar() {
  const [cursor, setCursor] = useState(() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); return d })
  const [selected, setSelected] = useState(new Date())
  const [events, setEvents] = useState([])
  const [sheet, setSheet] = useState(null)
  const [view, setView] = useState('month')
  const { tick, bump } = useRefresh()

  const range = useMemo(() => {
    const start = new Date(cursor)
    start.setDate(1 - ((cursor.getDay() + 6) % 7) - 7)
    const end = new Date(start)
    end.setDate(start.getDate() + 7 * 8)
    return [start, end]
  }, [cursor])

  const load = () => api.events(toLocalISO(range[0]), toLocalISO(range[1]), true).then(setEvents).catch(() => setEvents([]))
  useEffect(() => { load() }, [range, tick])

  const today = new Date()
  const cells = useMemo(() => {
    const curYear = cursor.getFullYear()
    const curMonth = cursor.getMonth()
    const firstDay = new Date(curYear, curMonth, 1)
    const offset = (firstDay.getDay() + 6) % 7
    const daysInMonth = new Date(curYear, curMonth + 1, 0).getDate()
    const daysInPrev = new Date(curYear, curMonth, 0).getDate()
    const res = []

    for (let i = 0; i < 42; i++) {
      const dayIdx = i - offset + 1
      const isOut = dayIdx < 1 || dayIdx > daysInMonth
      const num = dayIdx < 1 ? daysInPrev + dayIdx : dayIdx > daysInMonth ? dayIdx - daysInMonth : dayIdx
      const cellDate = new Date(curYear, dayIdx < 1 ? curMonth - 1 : dayIdx > daysInMonth ? curMonth + 1 : curMonth, num)
      const isToday = isSameDay(cellDate, today)
      const isSel = isSameDay(cellDate, selected)
      const dayEvs = (events || []).filter((e) => isSameDay(new Date(e.start), cellDate))
      res.push({
        num,
        isOut,
        isToday,
        isSel,
        date: cellDate,
        dotsCount: dayEvs.length,
        hasSpecial: dayEvs.some((e) => e.kind === 'order' || e.repeat),
        key: i,
      })
    }
    return res
  }, [cursor, events, selected, today])

  const dayEvents = (events || []).filter((e) => isSameDay(new Date(e.start), selected)).sort((a, b) => new Date(a.start) - new Date(b.start))
  const upcoming = (events || []).filter((e) => new Date(e.start) > today).sort((a, b) => new Date(a.start) - new Date(b.start)).slice(0, 5)

  const shiftMonth = (n) => {
    const d = new Date(cursor)
    d.setMonth(d.getMonth() + n)
    setCursor(d)
  }

  const goToday = () => {
    const d = new Date()
    setSelected(d)
    const c = new Date(d)
    c.setDate(1)
    c.setHours(0, 0, 0, 0)
    setCursor(c)
  }

  return (
    <div className="pg on" id="p-cal">
      {/* Шапка календаря */}
      <div className="top">
        <div>
          <h1 className="r" style={{ '--i': 0 }}>{MONTHS_NOM[cursor.getMonth()].toLowerCase()}</h1>
          <p className="sub r" style={{ '--i': 1 }}>{cursor.getFullYear()}</p>
        </div>
        <div className="hr r" style={{ '--i': 1 }}>
          <div className="sg">
            <span className={view === 'month' ? 'on' : ''} onClick={() => setView('month')}>месяц</span>
            <span className={view === 'week' ? 'on' : ''} onClick={() => setView('week')}>неделя</span>
          </div>
          <div className="sg">
            <span onClick={() => shiftMonth(-1)}>‹</span>
            <span onClick={goToday}>сегодня</span>
            <span onClick={() => shiftMonth(1)}>›</span>
          </div>
          <span className="btn" onClick={() => setSheet('new')}>+ событие</span>
        </div>
      </div>

      {/* Bento сетка календаря */}
      <div className="bento">
        {/* Карточка 1: Сетка календаря (s8) */}
        <section className="c s8 r" style={{ '--i': 2 }}>
          <div className="cal cal2" id="cal2">
            {'пн вт ср чт пт сб вс'.split(' ').map((w) => (
              <span className="w mono" key={w}>{w}</span>
            ))}
            {cells.slice(0, 35).map((c) => (
              <b
                key={c.key}
                className={`${c.isOut ? 'o' : ''} ${c.isToday ? 't' : ''}`}
                style={{ '--k': c.key, cursor: 'pointer', outline: c.isSel && !c.isToday ? '2px solid var(--line)' : 'none', borderRadius: '50%' }}
                onClick={() => setSelected(c.date)}
              >
                {c.isToday ? <span>{c.num}</span> : c.num}
                {c.dotsCount > 0 && (
                  <em>
                    {Array.from({ length: Math.min(3, c.dotsCount) }, (_, i) => (
                      <i key={i} className={c.hasSpecial ? 'y' : ''}></i>
                    ))}
                  </em>
                )}
              </b>
            ))}
          </div>
        </section>

        {/* Карточка 2: События дня (s4) */}
        <section className="c s4 r" style={{ '--i': 3 }}>
          <div className="hd">
            <h2>{isSameDay(selected, today) ? 'сегодня' : dayLabel(selected)}</h2>
            <small>{shortDate(selected)} · {dayEvents.length} {plural(dayEvents.length, 'событие', 'события', 'событий')}</small>
          </div>
          {dayEvents.length === 0 ? (
            <p style={{ color: 'var(--ink3)', paddingTop: '12px' }}>нет событий на этот день</p>
          ) : (
            dayEvents.map((e) => (
              <div className="rowi" key={e.id} onClick={() => setSheet(e)} style={{ cursor: 'pointer' }}>
                <time>{hhmm(e.start)}</time>
                <span className="t">
                  {e.title}
                  {e.sub && <small>{e.sub}</small>}
                </span>
              </div>
            ))
          )}
        </section>

        {/* Карточка 3: Ближайшее (s12) */}
        <section className="c s12 r" style={{ '--i': 4 }}>
          <div className="hd">
            <h2>ближайшее</h2>
            <small>7 дней · {upcoming.length}</small>
          </div>
          {upcoming.length === 0 ? (
            <p style={{ color: 'var(--ink3)', paddingTop: '12px' }}>нет предстоящих событий</p>
          ) : (
            upcoming.map((e) => {
              const d = new Date(e.start)
              return (
                <div className="rowi" key={e.id} onClick={() => setSheet(e)} style={{ cursor: 'pointer' }}>
                  <time>{WD[d.getDay()]} {hhmm(e.start)}</time>
                  <span className="t">{e.title}</span>
                </div>
              )
            })
          )}
        </section>
      </div>

      <EventSheet open={!!sheet} ev={sheet} day={selected} onClose={() => setSheet(null)} onDone={() => { setSheet(null); load(); bump() }} />
    </div>
  )
}
