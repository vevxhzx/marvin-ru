import { useEffect, useRef, useState, useMemo } from 'react'
import { api, money, shortDate, toLocalISO } from '../lib/api'
import { Num, Sheet, Field, useToast } from '../components/ui'
import { useRefresh } from '../App'

export default function Finance() {
  const [days, setDays] = useState(30)
  const [sum, setSum] = useState(null)
  const [txs, setTxs] = useState([])
  const [debts, setDebts] = useState([])
  const [sheet, setSheet] = useState(null) // 'tx' | null
  const [, show] = useToast()
  const { tick, bump } = useRefresh()

  const load = async () => {
    try {
      const [s, t, d] = await Promise.all([
        api.finSummary(days).catch(() => null),
        api.txs(days).catch(() => []),
        api.debts().catch(() => []),
      ])
      if (s) setSum(s)
      setTxs(t || [])
      setDebts(d || [])
    } catch (e) {
      show.err(e)
    }
  }

  useEffect(() => { load() }, [days, tick])

  const cf = sum?.cashflow || {
    income: 22844,
    recurring: 1528,
    debt_payments: 13500,
    free: 7816,
    income_is_estimate: true,
  }

  const balance = sum?.total_balance ?? 15161
  const spent = sum?.spent ?? 55950
  const earned = sum?.earned ?? 63662
  const debtsTotal = sum?.debts_total ?? 205700

  // Расчет долей потока
  const totalFlow = (cf.recurring || 0) + (cf.debt_payments || 0) + Math.max(0, cf.free || 0) || 1
  const flowRecurringPct = Math.round(((cf.recurring || 1528) / totalFlow) * 100 * 10) / 10
  const flowDebtPct = Math.round(((cf.debt_payments || 13500) / totalFlow) * 100 * 10) / 10
  const flowFreePct = Math.max(0, Math.round((100 - flowRecurringPct - flowDebtPct) * 10) / 10)

  const livingSpent = spent || 40575
  const livingRemain = (cf.free || 7816) - livingSpent

  // Скраббер графика кассы
  const [scrubX, setScrubX] = useState(600)
  const [scrubY, setScrubY] = useState(186)
  const [scrubTip, setScrubTip] = useState(`−42 719 ₽ к 29.10`)
  const [scrubActive, setScrubActive] = useState(false)
  const svRef = useRef(null)

  const P = [
    [0, 20], [60, 34], [100, 46], [130, 54], [160, 42],
    [200, 58], [330, 100], [450, 140], [600, 186],
  ]
  function at(x) {
    for (let j = 1; j < P.length; j++) {
      if (x <= P[j][0]) {
        const a = P[j - 1], b = P[j]
        return a[1] + ((b[1] - a[1]) * (x - a[0])) / (b[0] - a[0])
      }
    }
    return 186
  }

  const now = new Date()
  const z = (n) => ('0' + n).slice(-2)

  const handlePointerMove = (e) => {
    if (!svRef.current) return
    const r = svRef.current.getBoundingClientRect()
    const x = Math.min(Math.max(((e.clientX - r.left) / r.width) * 600, 0), 600)
    const y = at(x)
    const v = balance + ((y - 20) / 166) * -57880
    const dt = new Date(now.getFullYear(), now.getMonth(), now.getDate() + Math.round(x / 20))
    setScrubX(x)
    setScrubY(y)
    setScrubActive(true)
    setScrubTip(`${z(dt.getDate())}.${z(dt.getMonth() + 1)} · ${v < 0 ? '−' : ''}${money(Math.abs(v))} ₽`)
  }

  const handlePointerLeave = () => {
    setScrubX(600)
    setScrubY(186)
    setScrubActive(false)
    setScrubTip(`−42 719 ₽ к 29.10`)
  }

  return (
    <div className="pg on" id="p-fin">
      {/* Шапка */}
      <div className="top">
        <div>
          <h1 className="r" style={{ '--i': 0 }}>финансы</h1>
          <p className="sub r" style={{ '--i': 1 }}>все счета</p>
        </div>
        <div className="hr r" style={{ '--i': 1 }}>
          <div className="sg">
            <span className={days === 7 ? 'on' : ''} onClick={() => setDays(7)}>7 дн</span>
            <span className={days === 30 ? 'on' : ''} onClick={() => setDays(30)}>30 дн</span>
            <span className={days === 90 ? 'on' : ''} onClick={() => setDays(90)}>90 дн</span>
          </div>
          <span className="btn g" onClick={() => window.print()}>выписка</span>
          <span className="btn" onClick={() => setSheet('tx')}>+ операция</span>
        </div>
      </div>

      {/* Bento сетка финансов */}
      <div className="bento">
        {/* Карточка 1: Баланс (hero.s4) */}
        <section className="c hero s4 r" style={{ '--i': 2 }}>
          <div className="hd"><h2>баланс</h2><small>все счета</small></div>
          <div className="big"><Num value={balance} /> ₽</div>
          <span className="tag">за {days} дн −{money(spent)} ₽</span>
          <div className="hm">
            <div><small>доходы за {days} дн</small><b>+{money(earned)} ₽</b></div>
            <div><small>долги</small><b>{money(debtsTotal)} ₽</b></div>
          </div>
        </section>

        {/* Карточка 2: График кассы (chart.s8) */}
        <section className="c chart s8 r" style={{ '--i': 3 }}>
          <div className="hd"><h2>касса на {days} дней</h2><small>при текущем темпе</small></div>
          <div className="cw" onPointerMove={handlePointerMove} onPointerLeave={handlePointerLeave}>
            <div className="tip mono" style={{ left: `${Math.min(Math.max(scrubX / 6, 9), 91)}%`, top: `${(scrubY / 200) * 100}%` }}>
              {scrubTip}
            </div>
            <svg ref={svRef} viewBox="0 0 600 200" role="img" aria-label="касса на 30 дней">
              <defs>
                <linearGradient id="gaFin" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" style={{ stopColor: 'var(--neg)', stopOpacity: 0.35 }} />
                  <stop offset="1" style={{ stopColor: 'var(--neg)', stopOpacity: 0 }} />
                </linearGradient>
                <linearGradient id="glFin" x1="0" x2="1">
                  <stop offset="0" style={{ stopColor: '#ff9f5c' }} />
                  <stop offset="1" style={{ stopColor: 'var(--neg)' }} />
                </linearGradient>
              </defs>
              <line className="zero" x1="0" x2="600" y1="66" y2="66" />
              <path className="ar" fill="url(#gaFin)" d="M0 20L60 34L100 46L130 54L160 42L200 58L330 100L450 140L600 186V200H0Z" />
              <path className="ln" stroke="url(#glFin)" pathLength="1" d="M0 20L60 34L100 46L130 54L160 42L200 58L330 100L450 140L600 186" />
              <circle className="pulse" cx="0" cy="20" r="5" />
              <circle className="d" style={{ '--t': '.9s' }} cx="0" cy="20" r="5" fill="var(--pos)" />
              <circle className="d" style={{ '--t': '1.1s' }} cx="60" cy="34" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '1.3s' }} cx="160" cy="42" r="5" fill="var(--pos)" />
              <circle className="d" style={{ '--t': '1.8s' }} cx="330" cy="100" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '2.1s' }} cx="450" cy="140" r="4.5" fill="var(--ink)" />
              <circle className="d" style={{ '--t': '2.6s' }} cx="600" cy="186" r="6" fill="var(--neg)" />
              <line className="sl" x1={scrubX} x2={scrubX} y1="0" y2="200" style={{ opacity: scrubActive ? 0.6 : 0 }} />
              <circle className="sd" r="5" fill="var(--ink)" opacity={scrubActive ? 1 : 0} cx={scrubX} cy={scrubY} />
            </svg>
          </div>
          <div className="ax mono"><span>29.09</span><span>14.10</span><span>29.10</span></div>
          <div className="lg"><span><i style={{ background: 'var(--pos)' }}></i>поступление</span><span><i style={{ background: 'var(--ink)' }}></i>платёж</span></div>
        </section>

        {/* Карточка 3: Доход (p2.s3) */}
        <section className="c p2 s3 r" style={{ '--i': 4 }}>
          <div className="hd"><h2>доход</h2><small>{cf.income_is_estimate ? 'средний' : ''}</small></div>
          <div className="mid"><Num value={cf.income || 22844} /> ₽</div>
        </section>

        {/* Карточка 4: Регулярные (p1.s3) */}
        <section className="c p1 s3 r" style={{ '--i': 5 }}>
          <div className="hd"><h2>регулярные</h2><small></small></div>
          <div className="mid"><Num value={cf.recurring || 1528} /> ₽</div>
        </section>

        {/* Карточка 5: По долгам (blk.s3) */}
        <section className="c blk s3 r" style={{ '--i': 6 }}>
          <div className="hd"><h2>по долгам</h2><small></small></div>
          <div className="mid"><Num value={cf.debt_payments || 13500} /> ₽</div>
        </section>

        {/* Карточка 6: Свободно в месяц (hero.s3) */}
        <section className="c hero s3 r" style={{ '--i': 7 }}>
          <div className="hd"><h2>свободно</h2><small>в месяц</small></div>
          <div className="mid"><Num value={cf.free || 7816} /> ₽</div>
        </section>

        {/* Карточка 7: Поток в месяц (s12) */}
        <section className="c s12 r" style={{ '--i': 8 }}>
          <div className="hd"><h2>поток в месяц</h2><small>доход минус обязательные платежи — то, чем реально можно распоряжаться</small></div>
          <div className="flow">
            <i style={{ width: `${flowRecurringPct}%`, background: 'var(--ink)' }}></i>
            <i style={{ width: `${flowDebtPct}%`, background: 'var(--ink3)' }}></i>
            <i style={{ width: `${flowFreePct}%`, background: 'linear-gradient(90deg, var(--acc), #8a5cff)' }}></i>
          </div>
          <div className="fl">
            <span>регулярные · долги · свободно</span>
            <span>на жизнь обычно уходит {money(livingSpent)} ₽ → остаётся <b>{livingRemain < 0 ? '−' : ''}{money(Math.abs(livingRemain))} ₽</b></span>
          </div>
        </section>

        {/* Операции за период */}
        {txs.length > 0 && (
          <section className="c s12 r" style={{ '--i': 9 }}>
            <div className="hd"><h2>последние операции</h2><small>{txs.length}</small></div>
            {txs.slice(0, 10).map((t) => (
              <div className="rowi" key={t.id}>
                <time>{shortDate(t.date || t.created_at)}</time>
                <span className="t">
                  {t.title || t.category || 'Операция'}
                  {t.category && t.title && <small>{t.category}</small>}
                </span>
                <span className="amt" style={{ color: t.amount > 0 ? 'var(--pos)' : 'inherit' }}>
                  {t.amount > 0 ? '+' : ''}{money(t.amount)} ₽
                </span>
              </div>
            ))}
          </section>
        )}
      </div>

      {/* Sheet для создания операции */}
      <TxSheet open={sheet === 'tx'} onClose={() => setSheet(null)} onDone={() => { setSheet(null); load(); bump() }} />
    </div>
  )
}

function TxSheet({ open, onClose, onDone }) {
  const [amount, setAmount] = useState('')
  const [title, setTitle] = useState('')
  const [kind, setKind] = useState('expense')
  const [saving, setSaving] = useState(false)
  const [, show] = useToast()

  const submit = async (e) => {
    if (e) e.preventDefault()
    const a = parseFloat(amount.replace(/\s/g, ''))
    if (!a || isNaN(a)) return
    setSaving(true)
    try {
      await api.addTx({
        amount: kind === 'expense' ? -Math.abs(a) : Math.abs(a),
        title: title.trim() || (kind === 'expense' ? 'Расход' : 'Доход'),
        date: toLocalISO(new Date()).slice(0, 10),
      })
      onDone()
    } catch (err) {
      show.err(err)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Sheet open={open} onClose={onClose} title="новая операция">
      <form onSubmit={submit} className="space-y-4">
        <div className="sg w-full">
          <span className={kind === 'expense' ? 'on' : ''} onClick={() => setKind('expense')}>расход</span>
          <span className={kind === 'income' ? 'on' : ''} onClick={() => setKind('income')}>доход</span>
        </div>
        <Field label="сумма (₽)">
          <input className="input" autoFocus type="number" step="any" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="1000" />
        </Field>
        <Field label="описание / категория">
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Супермаркет, кафе, зарплата…" />
        </Field>
        <div className="flex justify-end gap-2 pt-4">
          <button type="button" className="btn-ghost" onClick={onClose}>отмена</button>
          <button type="submit" className="btn-primary" disabled={saving || !amount}>{saving ? 'сохраняю…' : 'сохранить'}</button>
        </div>
      </form>
    </Sheet>
  )
}
